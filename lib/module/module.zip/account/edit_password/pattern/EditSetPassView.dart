abstract class EditSetPassView {
  onSuccessEditSetPass(Map data);

  onFailEditSetPass(Map data);
}
