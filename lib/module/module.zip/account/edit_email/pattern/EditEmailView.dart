abstract class EditEmailView {
  onSuccessSendVerifyEmailChange(Map data);

  onFailSendVerifyEmailChange(Map data);

  onSuccessEditEmail(Map data);

  onFailEditEmail(Map data);

  onNetworkError();
}
