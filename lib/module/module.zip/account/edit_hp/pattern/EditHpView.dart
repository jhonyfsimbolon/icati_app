abstract class EditHpView {

  onNetworkError();

  onSuccessEditHp(Map data);

  onFailEditHp(Map data);

  onSuccessCheckPhone(Map data);

  onFailCheckPhone(Map data);

}
