abstract class EditSosMedView {
  onSuccessEditSosMed(Map data);

  onFailEditSosMed(Map data);

  onSuccessSosMed(Map data);

  onFailSosMed(Map data);

  onNetworkError();
}
