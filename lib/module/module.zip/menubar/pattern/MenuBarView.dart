abstract class MenuBarView {
  onSuccessCheckCompleteData(Map data);

  onFailCheckCompleteData(Map data);

  onSuccessLogout(Map data);

  onFailLogout(Map data);

  onSuccessNewNotification(Map data);

  onFailNewNotification(Map data);

  onSuccessChatNotif(Map data);
}
