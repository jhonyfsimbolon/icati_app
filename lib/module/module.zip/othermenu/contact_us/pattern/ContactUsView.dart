abstract class ContactUsView {
  onSuccessInfoContact(Map data);

  onFailInfoContact(Map data);

  onSuccessSendContact(Map data);

  onFailSendContact(Map data);

  onNetworkError();
}