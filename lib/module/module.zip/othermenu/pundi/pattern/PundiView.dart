abstract class PundiView {

  onNetworkError();

  onSuccessPundi(Map data);

  onFailPundi(Map data);

}
