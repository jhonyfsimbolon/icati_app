import 'package:flutter/material.dart';

class PundiWidgets {

  Widget displayPundiAmal() {
    return Column();
  }

  Widget displayPundiBerkah() {
    return Column();
  }

  Widget displayPundiKasih() {
    return Column();
  }
}