abstract class AboutUsView {
  onSuccessAboutUs(Map data);

  onFailAboutUs(Map data);

  onNetworkError();
}