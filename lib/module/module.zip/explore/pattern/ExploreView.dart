abstract class ExploreView {
  onSuccessNegara(Map data);

  onFailNegara(Map data);

  onSuccessProvince(Map data);

  onFailProvince(Map data);

  onSuccessCity(Map data);

  onFailCity(Map data);

  onSuccessSearchExplore(Map data);

  onFailSearchExplore(Map data);

  onNetworkError();
}
